# Handoff: Social Living Europe — strona konsorcjum (6 podstron)

## Overview
Witryna doradczo-finansowo-zarządcza dla **Konsorcjum Social Living Europe** (Fundacja DivideYou + Social Living Europe PSA). Konsorcjum NIE jest deweloperem ani wykonawcą — pozycjonowanie w całości brzmi: „pomagamy sfinansować i zrealizować projekty budownictwa społecznego" (doradztwo, montaż finansowania, strukturyzacja, zarządzanie). Ten ton musi być zachowany w całej implementacji.

Strona ma 6 podstron renderowanych jako jeden client-side router (bez przeładowania):
**Strona główna · O nas · Finansowanie · Modele · Współpraca · Kontakt.**

## About the Design Files
Pliki w tym pakiecie to **referencja projektowa stworzona w HTML** — prototyp pokazujący docelowy wygląd i zachowanie, a nie kod produkcyjny do skopiowania 1:1. Zadaniem jest **odtworzenie tych projektów w docelowym środowisku** (np. Next.js/React, Vue, Astro) z użyciem jego konwencji, routingu i bibliotek. Jeśli środowisko jeszcze nie istnieje — wybrać najwłaściwszy framework (rekomendacja: **Next.js + React**, bo treść jest statyczna a podstrony to naturalne route'y) i zaimplementować tam.

Plik źródłowy `Social Living Europe.dc.html` jest napisany w wewnętrznym formacie „Design Component" (szablon + klasa logiki). **Nie przenoś tego formatu** — czytaj go jako specyfikację: markup = struktura/style, klasa `Component` (sekcja `renderVals()`) = dane treściowe (tablice modeli, źródeł finansowania, cytatów, statystyk).

## Fidelity
**High-fidelity (hifi).** Finalne kolory, typografia, odstępy, układy i interakcje. Odtwórz UI pixel-perfect przy użyciu bibliotek docelowego repo. Wszystkie wartości (hex, px, font) podane niżej.

## Design Tokens

### Kolory
| Token | Hex | Użycie |
|---|---|---|
| Zieleń podstawowa (brand) | `#003f2d` | przyciski, aktywne linki, akcenty |
| Zieleń ciemna | `#012a1f` | ciemne sekcje, stopka, górny pasek, hero gradienty |
| Zieleń gradient (jaśniejsza) | `#06513a` / `#0a4632` / `#0d6346` | tła gradientowe, placeholdery zdjęć |
| Zieleń tekst-akcent | `#0d4a36` | wordmark w logo |
| Mięta (na ciemnym tle) | `#9fd9bf` / `#9fd0ba` | eyebrow/etykiety na ciemnym tle |
| Złoto jasne | `#c9a24a` | akcenty na ciemnym tle (kreski, numery, podkreślnik aktywnej strony) |
| Złoto ciemne | `#b08a3e` | akcenty na jasnym tle (kreski nad nagłówkami, górne ramki kart) |
| Zieleń „pozytyw" | `#1f8a5b` | lewa krawędź paneli „Co wnosimy / Korzyść / Dla kogo", kropki list |
| Czerwień „negatyw" | `#b5564c` | nagłówki „Kiedy nie warto", górne ramki kart problemu |
| Tekst główny | `#1c2b26` | body domyślny |
| Tekst nagłówków ciemny | `#012a1f` | h1/h2/h3 na jasnym tle |
| Tekst akapitów | `#46554f` / `#52615b` / `#3f4f49` | paragrafy, opisy |
| Tekst stonowany | `#6b7f76` / `#7d8c85` | eyebrow na jasnym tle, etykiety pól |
| Tło białe | `#ffffff` | sekcje jasne |
| Tło szare | `#f5f6f2` | sekcje naprzemienne |
| Tło zielonkawe (chip/panel) | `#eef3ef` / `#f1f6f2` | chipy, panele korzyści |
| Obramowania | `#e9e7df` / `#e4e2da` / `#d8e4dd` / `#dde3dc` | karty, separatory sekcji, inputy (`#d8ddd6`) |

### Typografia
- Nagłówki / akcenty serif: **Newsreader** (Google Fonts), wagi 400/500/600, dostępna kursywa (italic 400/500). Używana na h1–h3, dużych liczbach, cytatach, wordmarku.
- Tekst / UI sans: **Hanken Grotesk** (Google Fonts), wagi 400/500/600/700. Body, nawigacja, przyciski, etykiety.
- Import: `https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;0,6..72,600;1,6..72,400;1,6..72,500&family=Hanken+Grotesk:wght@400;500;600;700&display=swap`
- Skala (clamp, responsywna):
  - H1 hero: `clamp(34px,4.3–5.4vw,56–72px)`, weight 500, line-height ~1.05, letter-spacing -.5px
  - H2 sekcji: `clamp(28px,3.6–4vw,42–46px)`, weight 500, line-height ~1.12
  - H3 kart: 19–24px, weight 500/600
  - Lead/cytat: `clamp(19px,2.1–2.9vw,26–36px)`, często italic
  - Body: 15–17px, line-height 1.65–1.75
  - Eyebrow: 13px, letter-spacing 2.5–3px, uppercase, weight 600
  - Duże liczby (statystyki): `clamp(28px,2.8–9vw,38–128px)` Newsreader 500

### Odstępy / kształty
- Kontener: `max-width:1320px; margin:0 auto; padding:0 36px`. Węższy kontener treści: `max-width:1000px` (intro/cytaty).
- Padding sekcji pionowy: 84–100px (jasne), 72–96px (ciemne). Separator sekcji na stronach Finansowanie/Modele/Współpraca: `border-top:1px solid #e4e2da` + `padding:84–96px 0`.
- Border-radius: przyciski **2px**, karty 4–8px, chipy/„pigułki" 100px, pływający przycisk 100px.
- Cień pływającego przycisku: `0 10px 30px rgba(1,42,31,.32)`.
- Cień kart hover: `0 14px 36px rgba(1,42,31,.10)`.

## Layout globalny

### Górny pasek (sticky-above-header, na każdej podstronie)
Tło `#012a1f`, padding `8px 36px`, flex space-between. Lewo: „KONSORCJUM SOCIAL LIVING EUROPE" (12px, uppercase, letter-spacing 1.5px, kolor `#9fd9bf`, weight 600). Prawo: „Fundacja DivideYou · Social Living Europe PSA" (12px, `rgba(255,255,255,.62)`).

### Header (sticky, top:0, z-index:60)
Tło `rgba(255,255,255,.95)` + `backdrop-filter:blur(10px)`, dolna ramka `1px #e9e7df`, wysokość 80px, kontener 1320px.
- **Logo** (lewo, klik → Strona główna): obraz `assets/logo-mark-icon.png` (h:46px) + lockup tekstowy „Social Living" (Newsreader 19px 600 `#0d4a36`) nad „EUROPE" (9px, letter-spacing 3.5px, `#b08a3e`, 600). NIE dopisywać „Konsorcjum" w logo (świadoma decyzja).
- **Nav** (prawo, flex gap:10px): 5 pozycji + przycisk Kontakt. Każda pozycja to kolumna `flex-direction:column;align-items:center;gap:5px;padding:7px 14px;border-radius:8px`:
  - tekst 16.5px weight 500, kolor `#3f4f49`;
  - **hover**: tło pozycji `#eef3ef` (transition .15s) + tekst → `#003f2d`;
  - **aktywna strona**: pod tekstem złoty podkreślnik (pasek `height:2px;width:100%;background:#c9a24a;border-radius:2px`); pozycje nieaktywne mają pasek transparent (zachowuje wysokość → brak skoku layoutu).
  - Przycisk **Kontakt**: tło `#003f2d`, biały tekst 16px 600, radius 2px, padding `12px 22px`; hover `#012a1f` + `translateY(-1px)`.
  - ⚠️ Wskaźnik aktywnej strony musi być sterowany REAKTYWNIE ze stanu route (nie statycznym stylem) — patrz „State Management".

### Pływający przycisk kontaktu (fixed, na każdej podstronie)
`position:fixed;bottom:28px;right:28px;z-index:80`. Pigułka `#003f2d`, biały tekst „✉ Skontaktuj się" 15px 600, padding `15px 24px`, radius 100px, cień `0 10px 30px rgba(1,42,31,.32)`. Klik → Kontakt. Hover → `#012a1f`.

### Stopka (na każdej podstronie)
Tło `#012a1f`, górna ramka `4px solid #c9a24a`, padding `68px 0 34px`. Grid 4 kolumny (`1.6fr 1fr 1fr 1fr`):
1. Logo (białe — `filter:brightness(0) invert(1)`) + „Konsorcjum Social Living Europe" + opis „Konsorcjum (Fundacja DivideYou i Social Living Europe PSA) doradza, finansuje modelowo, strukturyzuje i zarządza projektami budownictwa społecznego — łącząc sektor prywatny, JST i kapitał finansowy."
2. „Strona" → Strona główna, O nas
3. „Oferta" → Finansowanie, Modele, Współpraca
4. „Kontakt" → office@sociallivingeurope.com · +48 607 695 900 · ul. Wrzesińska 12, Warszawa
Dół: `© 2026 Konsorcjum Social Living Europe — Fundacja DivideYou · Social Living Europe PSA. Wszelkie prawa zastrzeżone.` + Polityka prywatności / Regulamin.

## Screens / Views

### 1. Strona główna
Sekcje w kolejności:
1. **Hero** — pełna szerokość, min-height 86vh, tło gradient `120deg,#012a1f,#06513a` + obraz `assets/hero-green.png` (opacity .7) + nakładka `linear-gradient(90deg,rgba(1,30,22,.93)→.12)`. Eyebrow ze złotą kreską „Doradztwo · Finansowanie · Zarządzanie". H1 „Pomagamy sfinansować i zrealizować projekty budownictwa społecznego" (max 3 linie, max-width 960px). Akapit + 2 przyciski (biały „Sprawdź model finansowania" → Finansowanie; outline „Porozmawiajmy o współpracy" → Kontakt).
2. **Pasek ról** (tło `#003f2d`) — 4 kolumny z lewą złotą krawędzią `2px #c9a24a`: Doradzamy / Finansujemy modelowo / Strukturyzujemy / Zarządzamy (Newsreader 21px + opis).
3. **Czym jest budownictwo społeczne** — 2 kolumny: tekst „To znacznie więcej niż SIM i TBS" + 2 przyciski (Poznaj nasze modele / Skonsultuj projekt); obraz po prawej.
4. **Dlaczego teraz** (tło `#f5f6f2`) — nagłówek + grid 3×2 statystyk (białe komórki, separator 1px) `whyNow`: 2,1% / 45 mld zł / 126 tys. / 80% / 2% / 10 mld zł. Pod spodem cytat Czerniaka (ciemny blok, lewa złota krawędź).
5. **Nadchodząca ustawa** (tło `#f5f6f2`) — 4 karty `ustawa` (biała, górna ramka `3px #b08a3e`): 30–80% dotacji / Kredyt BGK 1–2% (do 50 lat) / 10% partycypacji mieszkańców / 34 mld zł do 2030. + nota o etapie legislacyjnym + przycisk Finansowanie.
6. **Pasek finansowania** (tło `#012a1f`) — nagłówek „Do 100% inwestycji…" + 4 kafle `finStats` (lewa złota krawędź): do 100% / 1–2% / do 50 lat / 30–80%. Przycisk „Poznaj sześć źródeł finansowania".
7. **Z kim pracujemy** — grid 5 kart-zdjęć (portret, gradient od dołu, tytuł+opis): Sektor prywatny / Samorządy / Duzi pracodawcy / Instytucje finansowe / Organizacje pozarządowe. Przycisk → Współpraca.
8. **Pięć gotowych modeli** (tło `#012a1f`) — grid 5 kafli `projectTypes` (lewa złota krawędź, złoty numer): SIM/TBS / Zakup przez wynajem / Program wiarygodności kredytowej / Mieszkania pracownicze / Budownictwo senioralne. Przycisk „Poznaj wszystkie modele".
9. **Jak zarabia się w tym modelu** — 2 kolumny (tekst + obraz) + pod spodem 5 etapów `revenueSteps` (górna złota kreska): Przygotowanie / Budowa / Zarządzanie / Montaż finansowania / Obsługa długoterminowa. Przycisk Kontakt.
10. **Misja** (tło `#f5f6f2`, wyśrodkowana) — duży akapit Newsreader.
11. **CTA** — ciemny gradient + obraz po prawej (opacity .5), „Masz projekt lub grunt? Sprawdźmy jego wykonalność" + przycisk.

### 2. O nas
1. **Hero** — ciemny gradient + obraz (opacity .36) + nakładka. Eyebrow „O nas". H1 „Od koncepcji do zarządzania: budownictwo społeczne, które działa".
2. **Lead** (Newsreader 23–34px) — „Social Living Europe to doradca, integrator i zarządca procesu…".
3. **Kim jesteśmy / Czego nie robimy** — 2 karty (biała + ciemna `#012a1f`), po 3 akapity. W ciemnej ostatnie zdanie miętą: „Nie obiecujemy, że jest łatwo. Obiecujemy, że wiemy jak."
4. **Problem, który rozwiązujemy** — narracja (max-width 1000px): „Polska ma problem mieszkaniowy. Ale nie ten, o którym się mówi." → 2 karty (Najem komercyjny / Kredyt hipoteczny, górna ramka `3px #b5564c`) → akapit o milionach Polaków.
5. **Luka czynszowa — duża liczba** — ciemny blok `#012a1f` lewa złota krawędź `5px`, grid 2 kolumny: lewo ogromne **„9,3 mln"** (Newsreader clamp do 128px) + „blisko 25% populacji"; prawo opis + źródło (prof. Czerniak, SGH).
6. **Potencjał vs realizacja** (tło `#f5f6f2`) — 4 statystyki `skala`: 300–400 tys. / 12 800 zł/m² / 740 vs 126 tys. / 4 mld zł.
7. **Nasz cel** — narracja o modelu wiedeńskim + cytat Prezesa KTBS (ciemny blok) + „My wierzymy, że to się w Polsce da i opłaca." + grid 2×2 kart `celCards` (Samorząd / Inwestor prywatny / Instytucja finansowa / Uczestnik programu, lewa krawędź `#1f8a5b`).
8. **Nasze kompetencje** — grid 3 kol `competencies` (6, górna kreska `2px #003f2d`). Przycisk Kontakt.
9. **Misja i wartości** (tło `#f5f6f2`) — grid 2 kol `values` (4 karty, górna ramka `3px #b08a3e`).
10. **CTA** „Doradzimy na każdym etapie projektu".

### 3. Finansowanie
1. **Hero — układ dzielony** (grid `1.05fr 1fr`, min-height clamp 420–600px): lewo panel `#012a1f` z eyebrow/H1 „To nie jest model »zbuduj i sprzedaj«."/akapit; prawo pełne zdjęcie.
2. **Intro** (max-width 1000px) — 3 akapity + wyróżniony italic „Dla właściwego inwestora to nie kompromis. To przewaga."
3. **Cytat Delowski** — ciemny blok, lewa złota krawędź.
4. **Sześć źródeł** `finSources` — naprzemienne wiersze (`dir: row / row-reverse`), każdy `padding:84px 0; border-top:1px solid #e4e2da`. Wiersz: obraz (złoty numer-badge lewy-górny + ciemna etykieta `tag` lewy-dolny) + tekst (H2 tytuł, złoty `headline`, akapity `body`, panel „Dla kogo" lewa krawędź `#1f8a5b`). Źródła: 01 Dotacja/Grant · 02 Kredyt preferencyjny BGK · 03 Partycypacja najemcy · 04 Wkład inwestora/aport gruntu · 05 Fundusze z impaktem społecznym · 06 Partycypacja gminy.
5. **Stopka sekcji** — ciemny gradient + obraz, „Jak to wszystko złożyć w jeden montaż?" + przycisk.

### 4. Modele
1. **Hero — pełnoekranowe zdjęcie** (min-height clamp 440–640px, align-items:flex-end) + nakładka gradient od dołu. Tytuł w półprzezroczystej „szklanej" karcie (`rgba(1,30,22,.55)`, backdrop-blur, lewa złota krawędź `4px`): eyebrow + H1 „Twój projekt. Nasze finansowanie. Gotowy model."
2. **Intro** + **blok „Dla kogo?"** (ciemny, lewa złota krawędź).
3. **Cytat KTBS** (jasny blok `#f5f6f2`, lewa krawędź `#b08a3e`).
4. **Pięć modeli** `modelsFull` — każdy `padding:90px 0; border-top:1px solid #e4e2da`: wiersz obraz (złoty badge `num`) + tekst (H2 tytuł, italic `subtitle`, akapity `body`); pod spodem grid 2 kol: panel „Co wnosimy" (`#1f8a5b`) + „Kto powinien rozmawiać z nami o tym modelu" (`#b08a3e`, tło `#faf6ee`). Modele: 01 SIM/TBS · 02 Zakup przez wynajem · 03 Program wiarygodności kredytowej · 04 Mieszkania pracownicze · 05 Budownictwo senioralne (obraz `assets/senior.png`).
5. **Stopka sekcji** „Nie wiesz, który model pasuje…" + przycisk „Umów bezpłatną konsultację".

### 5. Współpraca
1. **Hero — jasny, edytorski** (tło białe): eyebrow ze złotą kreską; grid `1.05fr 1fr` (H1 „Właściwi partnerzy przy jednym stole" + italic cytat-lead); pod spodem szerokie zdjęcie panoramiczne (h clamp 320–520px, radius 6px).
2. **Intro** (max-width 1000px) — lead Newsreader + 2 akapity.
3. **Pięć obszarów** `coop` — każdy `padding:96px 0; border-top:1px solid #e4e2da`. Nagłówek obszaru: numer w zielonym kółku (46px) + nazwa sektora (Newsreader clamp 24–36px) + złota linia wypełniająca. Pod spodem wiersz obraz + (tytuł H2, złota kreska, intro). Następnie grid 3 kart usług (`services`, górna ramka `3px #b08a3e`). Obszary: 01 Sektor prywatny · 02 Samorządy (3 usługi, w tym „Współpraca z lokalnymi pracodawcami…") · 03 Duzi pracodawcy · 04 Instytucje finansowe z impaktem społecznym · 05 Organizacje pozarządowe (usługa „Centrum wiedzy…" — NIE „Hub").
4. **Stopka sekcji** „Nie wiesz, od czego zacząć?" + przycisk „Umów rozmowę".

### 6. Kontakt
1. **Hero** (tło `#f5f6f2`) — eyebrow, H1 „Sprawdźmy wykonalność Twojego projektu", akapit.
2. **Formularz + panel** (grid `1.35fr 1fr`):
   - **Formularz**: chipy „Reprezentuję" (`roleOptions`: Inwestor / JST / Fundusz / bank / Inny), Imię+E-mail, sekcja „Krótka ankieta projektowa" (Lokalizacja, Typ nieruchomości, Liczba mieszkań, Szacowany koszt, Status rozmów z gminą [select], Oczekiwany model [select]), textarea. Przycisk „Wyślij zgłoszenie" + komunikat sukcesu (sc-if `sent`). Pod formularzem nota RODO (12.5px, szara): „Administratorem danych osobowych jest Fundacja DivideYou. Dane z formularza będą przetwarzane wyłącznie w celu obsługi przesłanego zapytania. Szczegóły… w Polityce Prywatności."
   - **Panel** „Konsorcjum Social Living Europe" (tło `#f5f6f2`): 2 kolumny podmiotów (Lider konsorcjum: Fundacja Divideyou, ul. Szopena 27/1, 35-055 Rzeszów · Prosta spółka akcyjna: Social Living Europe PSA, ul. Wrzesińska 12, 03-713 Warszawa) + 3 działy (Biuro zarządu office@…/+48 607 695 900 · Dział prawny j.matuszak@…/+48 504 072 346 · Dział rozwoju projektów p.nykiel@…/+48 570 001 011). Domena `sociallivingeurope.com`.

## Interactions & Behavior
- **Routing**: client-side, 6 widoków przełączanych bez przeładowania; przy zmianie route `window.scrollTo({top:0})`. W docelowym repo użyć natywnego routingu (Next.js route'y `/`, `/o-nas`, `/finansowanie`, `/modele`, `/wspolpraca`, `/kontakt`).
- **Nav active indicator**: złoty podkreślnik pod aktywną pozycją, sterowany ze stanu/route reaktywnie (musi się aktualizować przy każdej zmianie strony).
- **Hover**: pozycje nav (tło `#eef3ef` + tekst zieleń), przyciski (ciemnienie + translateY), karty (cień), karty „Z kim pracujemy" (lekkie uniesienie).
- **Formularz**: walidacja standardowa HTML; submit → preventDefault → pokazanie komunikatu „✓ Dziękujemy! Odezwiemy się ze wstępną oceną." (w realnym repo podłączyć backend/endpoint).
- **Transitions**: kolory/tła `.15s`; brak ciężkich animacji.
- **Responsywność**: prototyp zbudowany pod desktop (kontener 1320px). Dla wdrożenia dodać breakpointy — gridy wielokolumnowe → 1 kolumna na mobile, nav → menu hamburger, hero `grid 1.05fr 1fr` → stack.

## State Management
- `route`: 'home' | 'about' | 'financing' | 'models' | 'cooperation' | 'contact' (w realnym repo = URL/route).
- `sent`: bool — czy formularz kontaktowy wysłany (komunikat sukcesu).
- Wszystkie treści są statyczne — w klasie `Component.renderVals()` jako tablice: `roles, whyNow, ustawa, finStats, forWhom, projectTypes, revenueSteps, competencies, values, celCards, skala, finSources, modelsFull, coop, roleOptions` + cytaty `quoteCzerniak, quoteDelowski, quoteKtbs`. Skopiuj te dane 1:1 z pliku źródłowego (sekcja `renderVals`).

## Assets
W folderze `assets/` (skopiowane do tego pakietu):
- `logo-mark-icon.png` — logo (ikona budynków, przezroczyste tło). Używane w headerze i stopce (stopka: białe przez `filter:brightness(0) invert(1)`).
- `hero-green.png` — wizualizacja wireframe budynków w zielonym duotonie (hero strony głównej).
- `senior.png` — zdjęcie zielonego osiedla (model „Budownictwo senioralne").

Pozostałe zdjęcia w prototypie pochodzą z **Unsplash** (`images.unsplash.com/photo-<id>`) jako placeholdery — w produkcji zastąpić licencjonowanymi zdjęciami o tej samej tematyce (budownictwo, osiedla, finanse, spotkania biznesowe). Lista ID jest w pliku źródłowym (funkcja `img(id,w,h)` i pola `img:` w tablicach danych).

## Files
- `Social Living Europe.dc.html` — kompletny prototyp (źródło prawdy dla treści, układu i stylów).
- `assets/` — logo + obrazy własne.
